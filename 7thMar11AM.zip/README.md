Agentic AI POC
